from zetapy.legacy.main import getZeta, getIFR
