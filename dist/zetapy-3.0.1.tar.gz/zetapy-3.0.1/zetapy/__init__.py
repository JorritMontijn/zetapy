from zetapy.main import zetatest, zetatest2, zetatstest, zetatstest2, ifr
from zetapy.plot_dependencies import plotzeta, plotzeta2, plottszeta, plottszeta2

# from zetapy.msd import getMultiScaleDeriv
# from zetapy.dependencies import getPeak, getGumbel, getOnset, getTempOffset, flatten, calculatePeths
